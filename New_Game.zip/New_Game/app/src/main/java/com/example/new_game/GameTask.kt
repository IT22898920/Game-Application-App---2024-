package com.example.new_game



interface GameTask {
fun closeGame(mScore:Int)
}